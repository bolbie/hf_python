from setuptools import setup

setup(
    name='vsearch',
    version='1.0',
    description='The Head First Python Search Tools',
    author='Bolbie',
    author_email='soul_lucky@mail.ru',
    url='https://github.com/bolbie/hf_python',
    py_modules=['vsearch'],
)
